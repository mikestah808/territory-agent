#!/bin/bash

# Territory Intelligence Agent - Automated Deployment Helper
# This script automates as much as possible

echo "🤖 Territory Intelligence Agent - Deployment Helper"
echo "=================================================="
echo ""

# Check if gh CLI is installed (for GitHub operations)
if ! command -v gh &> /dev/null; then
    echo "⚠️  GitHub CLI not found. Will create manual instructions instead."
    MANUAL_MODE=true
else
    MANUAL_MODE=false
fi

echo "This script will help you deploy your agent in 3 steps:"
echo "1. Get your API keys (you need to do this)"
echo "2. Create GitHub repo (automated if you have gh CLI)"
echo "3. Deploy to Railway (one-click)"
echo ""

# Step 1: API Keys
echo "📋 STEP 1: Get Your API Keys"
echo "----------------------------"
echo ""
echo "Open these two links in your browser:"
echo ""
echo "🔑 Anthropic API Key:"
echo "   👉 https://console.anthropic.com/settings/keys"
echo "   Click 'Create Key', copy it"
echo ""
echo "🔔 Slack Webhook:"
echo "   👉 https://api.slack.com/apps"
echo "   Create New App → From scratch → 'Territory Agent'"
echo "   Incoming Webhooks → Toggle ON → Add New Webhook"
echo "   Copy the webhook URL"
echo ""

read -p "Press Enter when you have both keys ready..."

echo ""
read -p "Paste your Anthropic API key: " ANTHROPIC_KEY
read -p "Paste your Slack webhook URL: " SLACK_WEBHOOK

# Validate keys
if [[ ! $ANTHROPIC_KEY == sk-ant-* ]]; then
    echo "❌ Invalid Anthropic key (should start with sk-ant-)"
    exit 1
fi

if [[ ! $SLACK_WEBHOOK == https://hooks.slack.com/* ]]; then
    echo "❌ Invalid Slack webhook (should start with https://hooks.slack.com/)"
    exit 1
fi

echo "✅ Keys validated"
echo ""

# Step 2: GitHub
echo "📂 STEP 2: GitHub Repository"
echo "----------------------------"
echo ""

if [ "$MANUAL_MODE" = true ]; then
    echo "Manual steps required:"
    echo ""
    echo "1. Go to: https://github.com/new"
    echo "2. Repository name: territory-agent"
    echo "3. Make it Private"
    echo "4. Click 'Create repository'"
    echo "5. Click 'uploading an existing file'"
    echo "6. Upload all files from: $(pwd)"
    echo ""
    read -p "Press Enter when repository is created..."
    read -p "Enter your GitHub repository URL: " REPO_URL
else
    echo "Checking GitHub authentication..."
    if gh auth status &> /dev/null; then
        echo "✅ GitHub authenticated"
        echo ""
        echo "Creating repository 'territory-agent'..."
        
        # Create repo
        gh repo create territory-agent --private --source=. --remote=origin
        
        # Initial commit and push
        git init
        git add .
        git commit -m "Initial commit - Territory Intelligence Agent"
        git branch -M main
        git push -u origin main
        
        REPO_URL=$(gh repo view --json url -q .url)
        echo "✅ Repository created: $REPO_URL"
    else
        echo "❌ Not authenticated with GitHub"
        echo "Run: gh auth login"
        exit 1
    fi
fi

echo ""

# Step 3: Railway
echo "🚀 STEP 3: Deploy to Railway"
echo "----------------------------"
echo ""
echo "Click this button to deploy (will open in browser):"
echo ""
echo "[![Deploy on Railway](https://railway.app/button.svg)](https://railway.app/new/template?template=https://github.com/YOUR_USERNAME/territory-agent)"
echo ""
echo "OR manually:"
echo "1. Go to: https://railway.app/"
echo "2. Sign in with GitHub"
echo "3. New Project → Deploy from GitHub repo"
echo "4. Select: territory-agent"
echo "5. Add environment variables:"
echo ""
echo "   ANTHROPIC_API_KEY=$ANTHROPIC_KEY"
echo "   SLACK_WEBHOOK_URL=$SLACK_WEBHOOK"
echo ""
echo "   (Other variables have defaults already set)"
echo ""
echo "6. Click Deploy"
echo ""

# Create .env file for local testing
cat > .env << EOF
ANTHROPIC_API_KEY=$ANTHROPIC_KEY
SLACK_WEBHOOK_URL=$SLACK_WEBHOOK
TERRITORY_SOURCE=outreach
SCAN_SCHEDULE=0 */6 * * *
RESCAN_INTERVAL_HOURS=24
HEADCOUNT_GROWTH_THRESHOLD=15
AUTO_DRAFT_OUTREACH=true
REQUIRE_APPROVAL=true
RUN_ON_STARTUP=true
NODE_ENV=development
EOF

echo "✅ Created .env file for local testing"
echo ""
echo "To test locally before deploying:"
echo "  npm install"
echo "  npm run init-db"
echo "  npm start"
echo ""

read -p "Press Enter to open Railway deployment page..." 
open "https://railway.app/new" 2>/dev/null || xdg-open "https://railway.app/new" 2>/dev/null || echo "Open manually: https://railway.app/new"

echo ""
echo "✅ Deployment helper complete!"
echo ""
echo "Next steps:"
echo "1. Complete Railway deployment (if not done)"
echo "2. Check Slack for first scan notification (within 2 min)"
echo "3. Add/remove accounts in Outreach - agent auto-syncs"
echo ""
echo "Monitor your agent:"
echo "  Railway: https://railway.app/dashboard"
echo "  Slack: Check your configured channel"
echo ""
